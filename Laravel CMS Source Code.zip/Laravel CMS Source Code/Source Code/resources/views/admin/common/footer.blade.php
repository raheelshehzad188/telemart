<footer class="main-footer" style="padding-bottom:35px">
  <div class="col-xs-12 text-right" > <b>Version</b> 2.2 </div>
</footer>
